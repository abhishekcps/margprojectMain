import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-three',
  templateUrl: './service-three.component.html',
  styleUrls: ['./service-three.component.scss']
})
export class ServiceThreeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
