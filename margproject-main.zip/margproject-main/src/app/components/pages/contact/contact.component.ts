import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {
  trialForm: FormGroup;
  
  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.initForm();
  }

  initForm(): void {
    this.trialForm = this.fb.group({
      mobileNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      pinCode: ['', [Validators.required, Validators.pattern('^[0-9]{6}$')]],
      name: ['', [Validators.required, Validators.minLength(3)]]
    });
  }

  onSubmit(): void {
    if (this.trialForm.valid) {
      console.log('Form submitted with values:', this.trialForm.value);
      // Here you would typically call a service to handle the form submission
      // this.contactService.submitTrialRequest(this.trialForm.value).subscribe(...);
      
      // Reset form after submission
      this.trialForm.reset();
    } else {
      // Mark all fields as touched to trigger validation errors
      Object.keys(this.trialForm.controls).forEach(key => {
        this.trialForm.get(key).markAsTouched();
      });
    }
  }
}