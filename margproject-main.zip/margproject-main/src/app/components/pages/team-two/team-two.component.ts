import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-team-two',
  templateUrl: './team-two.component.html',
  styleUrls: ['./team-two.component.scss']
})
export class TeamTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
