import { Component } from '@angular/core';

@Component({
  selector: 'app-services-four',
  standalone: true,
  imports: [],
  templateUrl: './services-four.component.html',
  styleUrl: './services-four.component.scss'
})
export class ServicesFourComponent {

}
