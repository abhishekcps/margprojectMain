import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServicesFourComponent } from './services-four.component';

describe('ServicesFourComponent', () => {
  let component: ServicesFourComponent;
  let fixture: ComponentFixture<ServicesFourComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ServicesFourComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ServicesFourComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
