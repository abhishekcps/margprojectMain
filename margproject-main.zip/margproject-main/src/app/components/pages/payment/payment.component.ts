import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss'] // Updated to scss
})
export class PaymentComponent implements OnInit {
  // Tab management
  activeTab: string = 'eBusiness';

  // Form groups
  businessForm: FormGroup;
  
  // Additional properties
  hasGstin: boolean = true;
  plans = [
    { id: 1, name: 'Basic Plan', price: 5000, offer: 0 },
    { id: 2, name: 'Standard Plan', price: 10000, offer: 5 },
    { id: 3, name: 'Premium Plan', price: 15000, offer: 10 }
  ];

  constructor(private fb: FormBuilder) {
    // Initialize form here
    this.businessForm = this.fb.group({
      companyId: ['', Validators.required],
      captcha: ['', Validators.required],
      paymentType: ['Yearly'],
      amount: [0, Validators.required],
      discount: [0],
      gst: [{value: 0, disabled: true}],
      payableAmount: [{value: 0, disabled: true}],
      eOrderRetailBilling: [true],
      selectedPlan: [1],
      mobile: ['', Validators.required],
      emailId: ['', [Validators.required, Validators.email]],
      firmName: ['', Validators.required],
      address: ['', Validators.required],
      country: ['INDIA', Validators.required],
      stateProvince: ['', Validators.required],
      city: ['', Validators.required],
      zipPostalCode: ['', Validators.required],
      remarks: [''],
      gstin: [''],
      dontHaveGstin: [false]
    });

    // Watch for changes to calculate values
    this.watchFormChanges();
  }

  ngOnInit(): void {
    // Additional initialization if needed
    this.calculateAmounts();
  }

  // Tab switching function
  switchTab(tabName: string): void {
    this.activeTab = tabName;
  }

  // Toggle GSTIN function
  toggleGstin(): void {
    this.hasGstin = !this.businessForm.get('dontHaveGstin')?.value;
    
    if (!this.hasGstin) {
      this.businessForm.get('gstin')?.setValue('');
    }
  }

  // Calculate GST and payable amount
  calculateAmounts(): void {
    const amount = this.businessForm.get('amount')?.value || 0;
    const discount = this.businessForm.get('discount')?.value || 0;
    const discountedAmount = amount - discount;
    const gst = discountedAmount * 0.18; // 18% GST
    const payableAmount = discountedAmount + gst;

    this.businessForm.patchValue({
      gst: gst.toFixed(2),
      payableAmount: payableAmount.toFixed(2)
    });
  }

  // Watch form changes to update calculations
  private watchFormChanges(): void {
    this.businessForm.get('amount')?.valueChanges.subscribe(() => this.calculateAmounts());
    this.businessForm.get('discount')?.valueChanges.subscribe(() => this.calculateAmounts());
  }

  // Form submission handling
  onSubmit(): void {
    if (this.businessForm.valid) {
      // Process the form submission here
      console.log('Form submitted:', this.businessForm.value);
    } else {
      // Mark all form controls as touched to trigger validation messages
      Object.keys(this.businessForm.controls).forEach(key => {
        this.businessForm.get(key)?.markAsTouched();
      });
    }
  }
}