import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { PaymentComponent } from './payment.component';

describe('PaymentComponent', () => {
  let component: PaymentComponent;
  let fixture: ComponentFixture<PaymentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentComponent ],
      imports: [ ReactiveFormsModule ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize with default tab as eBusiness', () => {
    expect(component.activeTab).toBe('eBusiness');
  });

  it('should switch tabs correctly', () => {
    component.switchTab('Licence');
    expect(component.activeTab).toBe('Licence');
    
    component.switchTab('Others');
    expect(component.activeTab).toBe('Others');
    
    component.switchTab('eBusiness');
    expect(component.activeTab).toBe('eBusiness');
  });

  it('should toggle GSTIN correctly', () => {
    expect(component.hasGstin).toBe(true);
    
    component.businessForm.get('dontHaveGstin')?.setValue(true);
    component.toggleGstin();
    expect(component.hasGstin).toBe(false);
    
    component.businessForm.get('dontHaveGstin')?.setValue(false);
    component.toggleGstin();
    expect(component.hasGstin).toBe(true);
  });

  it('should calculate GST and payable amount correctly', () => {
    component.businessForm.patchValue({
      amount: 1000,
      discount: 100
    });
    
    component.calculateAmounts();
    
    expect(component.businessForm.get('gst')?.value).toBe('162.00');
    expect(component.businessForm.get('payableAmount')?.value).toBe('1062.00');
  });

  it('should mark form as invalid when required fields are empty', () => {
    expect(component.businessForm.valid).toBeFalsy();
  });

  it('should mark form as valid when all required fields are filled', () => {
    component.businessForm.patchValue({
      companyId: 'COMP123',
      captcha: 'WRYJZB',
      amount: 1000,
      mobile: '9876543210',
      emailId: 'test@example.com',
      firmName: 'Test Firm',
      address: '123 Test Street',
      country: 'INDIA',
      stateProvince: 'Test State',
      city: 'Test City',
      zipPostalCode: '123456'
    });
    
    expect(component.businessForm.valid).toBeTruthy();
  });
});