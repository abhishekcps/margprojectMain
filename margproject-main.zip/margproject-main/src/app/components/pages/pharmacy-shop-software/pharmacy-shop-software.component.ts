import { Component } from '@angular/core';

@Component({
  selector: 'app-pharmacy-shop-software',
  standalone: true,
  imports: [],
  templateUrl: './pharmacy-shop-software.component.html',
  styleUrl: './pharmacy-shop-software.component.scss'
})
export class PharmacyShopSoftwareComponent {

}
